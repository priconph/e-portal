<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_redirect
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Redirect link controller class.
 *
 * @since  1.6
 */
class RedirectControllerLink extends JControllerForm
{
	// Parent class access checks are sufficient for this controller.
}
